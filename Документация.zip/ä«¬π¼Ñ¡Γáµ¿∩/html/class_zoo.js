var class_zoo =
[
    [ "Zoo", "class_zoo.html#a5b2fef572705f7b4d0dae63a67b4d6fa", null ],
    [ "addEvent", "class_zoo.html#afb2334c683c0eb21d5db6a7c3370111a", null ],
    [ "cureAnimal", "class_zoo.html#ae6cd6e744b79a9b2c18269f3a5900a14", null ],
    [ "generateAnimalMarket", "class_zoo.html#aa5fa142a51acb502ab62ae1295c82f42", null ],
    [ "getTotalAnimals", "class_zoo.html#a0a65b78cc40385d28bcd1bb45e5469d9", null ],
    [ "nextDay", "class_zoo.html#ab2ece85756cb835be177a024cb030765", null ],
    [ "processRandomEvents", "class_zoo.html#a870ec1f6fb0402847e59cfd5ba8cf332", null ],
    [ "refreshAnimalMarket", "class_zoo.html#a0e94d5c2aced9f34140356e76cf7cd0c", null ],
    [ "resetDailyCounters", "class_zoo.html#ae9c060bf3670c2e3c6559609f860836e", null ],
    [ "animalMarket", "class_zoo.html#ac7920cc5bdc380c521258a3c6355dab6", null ],
    [ "animalsBoughtToday", "class_zoo.html#af664d4c5762c53054ebd7077c4f37303", null ],
    [ "dailyEvents", "class_zoo.html#adb4c5d16e981bf79155adecc29c94acc", null ],
    [ "day", "class_zoo.html#a3dd071e67f4b28c9b169f84f51288b9d", null ],
    [ "employees", "class_zoo.html#afbeab4b171f232a6591398dfe6011362", null ],
    [ "enclosures", "class_zoo.html#ac7605bb5797e3ea2f91d598a85ced7c9", null ],
    [ "food", "class_zoo.html#a32599c89da8a208f5f276f9fe400db1f", null ],
    [ "money", "class_zoo.html#a0f52301f019bbde9e4ed5962faf60d08", null ],
    [ "name", "class_zoo.html#a6245416c36dddf4a4689a9326b1a31f2", null ],
    [ "popularity", "class_zoo.html#a42b8020c9107c05d1d15546b86fb5fcf", null ]
];