var class_employee =
[
    [ "Employee", "class_employee.html#ae0d34140f2cfbf70716423a4e54d9485", null ],
    [ "currentAnimals", "class_employee.html#ab514a2d56291545da0908c947de37d28", null ],
    [ "maxAnimals", "class_employee.html#a7287ee2a64a5806121713df69f92b005", null ],
    [ "name", "class_employee.html#a1934a85a4a9a8fd00ae04425c5cc4f67", null ],
    [ "position", "class_employee.html#a050f2e45bdcd813b690177a7e55b6a48", null ],
    [ "salary", "class_employee.html#a10872e0e01c0412d8b5efafc36bb8226", null ]
];