var class_enclosure =
[
    [ "Enclosure", "class_enclosure.html#ad648c4f898e682f38f8fe12da71be54c", null ],
    [ "addAnimal", "class_enclosure.html#a175957997d42de7a13623c86a917c37c", null ],
    [ "breedAnimals", "class_enclosure.html#a4d799bcb0d3410b844a6c2cab8164e3a", null ],
    [ "calculateCost", "class_enclosure.html#a7994fc31dd0024fd6a889d6e680d7185", null ],
    [ "calculateDailyCost", "class_enclosure.html#ab08c2bd1570344d61c13f080fe303caa", null ],
    [ "canAddAnimal", "class_enclosure.html#a6a3ab6883bc6662a1e4cf8489e4e57df", null ],
    [ "infectRandomAnimal", "class_enclosure.html#a7e0b26c3e8fd1fb3e32ba4ac2aa161c0", null ],
    [ "removeAnimal", "class_enclosure.html#afaf7f7c39334f92eff1680649e20e230", null ],
    [ "spreadVirus", "class_enclosure.html#ae26b10c47b33d906811b221f1b0c69aa", null ],
    [ "upgrade", "class_enclosure.html#af26d5d32864947a2c37c2ab632950e70", null ],
    [ "animals", "class_enclosure.html#aff0a9cb1021ec0d2f41ecfd186ddf94f", null ],
    [ "capacity", "class_enclosure.html#af82c31912f367606c452b69e3cea5891", null ],
    [ "climate", "class_enclosure.html#ad68744badbd04a3b6e6589340b42c5c3", null ],
    [ "dailyCost", "class_enclosure.html#a1713bb40e9da69bdc84c07e760f040ba", null ],
    [ "level", "class_enclosure.html#ab34a3f63ca56297a917bf6bdc7bb743f", null ]
];