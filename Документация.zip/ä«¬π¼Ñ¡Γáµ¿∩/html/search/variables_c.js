var searchData=
[
  ['salary_0',['salary',['../class_employee.html#a10872e0e01c0412d8b5efafc36bb8226',1,'Employee']]],
  ['species_1',['species',['../class_animal.html#a70a223fc101b56962088b16a8b18534b',1,'Animal']]]
];
