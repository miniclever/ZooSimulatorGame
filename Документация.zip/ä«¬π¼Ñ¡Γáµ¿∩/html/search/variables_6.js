var searchData=
[
  ['iscarnivore_0',['isCarnivore',['../class_animal.html#a14e03f4ca6b1eb8f6a3f4b585c2cde2b',1,'Animal']]],
  ['isinfected_1',['isInfected',['../class_animal.html#a06e648f316f8a1df7ad5edc81360eddd',1,'Animal']]]
];
