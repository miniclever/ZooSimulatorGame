var searchData=
[
  ['maxanimals_0',['maxAnimals',['../class_employee.html#a7287ee2a64a5806121713df69f92b005',1,'Employee']]],
  ['money_1',['money',['../class_zoo.html#a0f52301f019bbde9e4ed5962faf60d08',1,'Zoo']]]
];
