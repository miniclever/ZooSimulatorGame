var searchData=
[
  ['diesofoldage_0',['diesOfOldAge',['../class_animal.html#af1026bdc8810ef8f737a8d289040f3c0',1,'Animal']]]
];
