var searchData=
[
  ['level_0',['level',['../class_enclosure.html#ab34a3f63ca56297a917bf6bdc7bb743f',1,'Enclosure']]]
];
