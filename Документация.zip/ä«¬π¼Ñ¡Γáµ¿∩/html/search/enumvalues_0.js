var searchData=
[
  ['aquatic_0',['AQUATIC',['../class_animal.html#a83132a903f75e03a54772ba3b3c22f3da6429181b8ce852e44a9c5c7dc8188e36',1,'Animal']]],
  ['arctic_1',['ARCTIC',['../class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197a2c50febeb5c38afbea69cce3edc651f8',1,'Animal']]]
];
