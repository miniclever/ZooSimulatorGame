var searchData=
[
  ['parents_0',['parents',['../class_animal.html#a0d85356dfe79acf519c2f5d2706aa8ce',1,'Animal']]],
  ['popularity_1',['popularity',['../class_zoo.html#a42b8020c9107c05d1d15546b86fb5fcf',1,'Zoo']]],
  ['position_2',['position',['../class_employee.html#a050f2e45bdcd813b690177a7e55b6a48',1,'Employee']]]
];
