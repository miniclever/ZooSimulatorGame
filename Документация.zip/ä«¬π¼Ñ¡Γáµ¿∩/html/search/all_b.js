var searchData=
[
  ['ocean_0',['OCEAN',['../class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197a58fdd67a9d68ec7a6407e74fb948ee62',1,'Animal']]],
  ['ocean_5fspecies_1',['OCEAN_SPECIES',['../_source_8cpp.html#a30f07290f59be370e2e2f3e33d2101d5',1,'Source.cpp']]],
  ['operator_2b_2',['operator+',['../class_animal.html#a92d4e93d9cc719dda6360865857d748c',1,'Animal']]]
];
