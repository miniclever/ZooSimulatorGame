var searchData=
[
  ['land_0',['LAND',['../class_animal.html#a83132a903f75e03a54772ba3b3c22f3da0f6f6921caff684fc74a422b2b4d1498',1,'Animal']]]
];
