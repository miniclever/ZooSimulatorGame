var searchData=
[
  ['climate_0',['Climate',['../class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197',1,'Animal']]]
];
