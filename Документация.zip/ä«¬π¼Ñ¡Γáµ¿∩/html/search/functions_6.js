var searchData=
[
  ['infectrandomanimal_0',['infectRandomAnimal',['../class_enclosure.html#a7e0b26c3e8fd1fb3e32ba4ac2aa161c0',1,'Enclosure']]],
  ['isaquatic_1',['isAquatic',['../class_animal.html#af4e9475a56c570f228d5aa3d5b07559c',1,'Animal']]]
];
