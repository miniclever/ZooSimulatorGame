var searchData=
[
  ['capacity_0',['capacity',['../class_enclosure.html#af82c31912f367606c452b69e3cea5891',1,'Enclosure']]],
  ['climate_1',['climate',['../class_animal.html#aa33ee4b38efd0d69dfbb3c4273b347df',1,'Animal::climate'],['../class_enclosure.html#ad68744badbd04a3b6e6589340b42c5c3',1,'Enclosure::climate']]],
  ['currentanimals_2',['currentAnimals',['../class_employee.html#ab514a2d56291545da0908c947de37d28',1,'Employee']]]
];
