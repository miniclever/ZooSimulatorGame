var searchData=
[
  ['type_0',['Type',['../class_animal.html#a83132a903f75e03a54772ba3b3c22f3d',1,'Animal']]]
];
