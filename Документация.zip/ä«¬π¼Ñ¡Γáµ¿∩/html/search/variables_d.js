var searchData=
[
  ['type_0',['type',['../class_animal.html#a98ff69e5efae10516efa3d4a767f60ee',1,'Animal']]]
];
