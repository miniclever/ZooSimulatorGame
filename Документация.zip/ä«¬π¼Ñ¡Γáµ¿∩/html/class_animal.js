var class_animal =
[
    [ "Climate", "class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197", [
      [ "DESERT", "class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197ab8066245944264b77cf27af4e5cab935", null ],
      [ "FOREST", "class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197afbc5e1c764f938e54edef9da5bde5e62", null ],
      [ "ARCTIC", "class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197a2c50febeb5c38afbea69cce3edc651f8", null ],
      [ "OCEAN", "class_animal.html#a10ae8fa2493664a1f2ff59df5ba2a197a58fdd67a9d68ec7a6407e74fb948ee62", null ]
    ] ],
    [ "Type", "class_animal.html#a83132a903f75e03a54772ba3b3c22f3d", [
      [ "LAND", "class_animal.html#a83132a903f75e03a54772ba3b3c22f3da0f6f6921caff684fc74a422b2b4d1498", null ],
      [ "AQUATIC", "class_animal.html#a83132a903f75e03a54772ba3b3c22f3da6429181b8ce852e44a9c5c7dc8188e36", null ]
    ] ],
    [ "Animal", "class_animal.html#ad8912997be12eff56286149e1ce6491c", null ],
    [ "calculateMaintenanceCost", "class_animal.html#a6aa6a856670c9c301cd14e7ba440364b", null ],
    [ "calculatePrice", "class_animal.html#adeb5ca19b822972c58c7f6a63d29f0f8", null ],
    [ "diesOfOldAge", "class_animal.html#af1026bdc8810ef8f737a8d289040f3c0", null ],
    [ "growOlder", "class_animal.html#aeb3dd89243fc5de18945df5f7ee0ab24", null ],
    [ "isAquatic", "class_animal.html#af4e9475a56c570f228d5aa3d5b07559c", null ],
    [ "operator+", "class_animal.html#a92d4e93d9cc719dda6360865857d748c", null ],
    [ "printParents", "class_animal.html#ab3aecb4b53c5cd41421474cb5a3a2bbc", null ],
    [ "ageInDays", "class_animal.html#a64181a3d57dab7e26a5b772d1e46474c", null ],
    [ "climate", "class_animal.html#aa33ee4b38efd0d69dfbb3c4273b347df", null ],
    [ "gender", "class_animal.html#a738d9786d1549040b0f324780966bc57", null ],
    [ "isCarnivore", "class_animal.html#a14e03f4ca6b1eb8f6a3f4b585c2cde2b", null ],
    [ "isInfected", "class_animal.html#a06e648f316f8a1df7ad5edc81360eddd", null ],
    [ "name", "class_animal.html#a9cf3bfd9070daec7b3bbc87cbd958f35", null ],
    [ "parents", "class_animal.html#a0d85356dfe79acf519c2f5d2706aa8ce", null ],
    [ "species", "class_animal.html#a70a223fc101b56962088b16a8b18534b", null ],
    [ "type", "class_animal.html#a98ff69e5efae10516efa3d4a767f60ee", null ],
    [ "weight", "class_animal.html#a9a3b22f243f7109c57f36b3c660feb6e", null ]
];